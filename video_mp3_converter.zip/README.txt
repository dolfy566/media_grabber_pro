Video & Audio Downloader - Manual de instalación y uso

1. Requisitos:
   - Kali Linux
   - Conexión a internet

2. Instalación:
   - Abre una terminal en la carpeta del script
   - Ejecuta:
     chmod +x video_mp3_converter.sh
     ./video_mp3_converter.sh

3. Funciones:
   - Descargar videos o audios desde YouTube, TikTok, etc.
   - Convertir videos locales a audio
   - Cambiar la carpeta de descargas
   - Instalar/desinstalar reproductores multimedia (VLC, Audacity, etc.)

4. El programa añade accesos al menú del sistema automáticamente.
