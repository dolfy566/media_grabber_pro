import os
import tkinter as tk
from tkinter import filedialog, simpledialog, messagebox
import subprocess

def descargar_video(audio=False, playlist=False):
    url = simpledialog.askstring("URL del video", "Pega la URL:")
    if not url:
        return
    carpeta = filedialog.askdirectory(title="Selecciona carpeta de descarga")
    if not carpeta:
        return

    cmd = ["yt-dlp", url, "-P", carpeta]
    if not playlist:
        cmd.append("--no-playlist")
    if audio:
        cmd += ["-x", "--audio-format", "mp3"]

    subprocess.call(cmd)

def extraer_audio_local():
    archivo = filedialog.askopenfilename(title="Selecciona video")
    if not archivo:
        return
    carpeta = filedialog.askdirectory(title="Guardar MP3")
    if not carpeta:
        return
    salida = os.path.join(carpeta, os.path.splitext(os.path.basename(archivo))[0] + ".mp3")
    subprocess.call(["ffmpeg", "-i", archivo, "-vn", "-ab", "192k", "-ar", "44100", salida])

root = tk.Tk()
root.title("Multi Downloader")
root.geometry("300x200")

tk.Button(root, text="Descargar video", command=lambda: descargar_video(audio=False, playlist=False)).pack(pady=5)
tk.Button(root, text="Descargar audio", command=lambda: descargar_video(audio=True, playlist=False)).pack(pady=5)
tk.Button(root, text="Descargar playlist completa", command=lambda: descargar_video(audio=False, playlist=True)).pack(pady=5)
tk.Button(root, text="Extraer audio de video local", command=extraer_audio_local).pack(pady=5)
tk.Button(root, text="Salir", command=root.quit).pack(pady=5)

root.mainloop()
