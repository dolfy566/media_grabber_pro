#!/bin/bash

# Script: Video & Audio Downloader for Kali Linux
# Verifica y instala dependencias necesarias

check_and_install() {
  for pkg in yt-dlp ffmpeg zenity; do
    if ! command -v $pkg &> /dev/null; then
      echo "Instalando $pkg..."
      sudo apt update && sudo apt install -y $pkg
    fi
  done
}

select_folder() {
  DEST=$(zenity --file-selection --directory --title="Selecciona la carpeta de descarga")
  echo "$DEST" > ~/.video_audio_downloader_dir
}

main_menu() {
  if [ ! -f ~/.video_audio_downloader_dir ]; then
    select_folder
  else
    DEST=$(cat ~/.video_audio_downloader_dir)
  fi

  while true; do
    OPTION=$(zenity --list --title="Video & Audio Downloader" --column="Opciones"       "Descargar video o audio desde URL"       "Convertir un video local a audio"       "Instalar reproductores multimedia"       "Desinstalar reproductores multimedia"       "Cambiar carpeta de descarga"       "Salir")

    case "$OPTION" in
      "Descargar video o audio desde URL")
        URL=$(zenity --entry --title="Introduce la URL" --text="URL del video:")
        TYPE=$(zenity --list --title="Tipo de descarga" --column="Tipo" "Solo este video" "Lista completa")
        FORMAT=$(zenity --list --title="Formato" --column="Formato" "Video" "Audio")

        if [[ "$FORMAT" == "Audio" ]]; then
          yt-dlp -x --audio-format mp3 "$URL" -P "$DEST" | zenity --progress --pulsate --auto-close
        else
          [[ "$TYPE" == "Solo este video" ]] && OPT="--no-playlist" || OPT=""
          yt-dlp $OPT "$URL" -P "$DEST" | zenity --progress --pulsate --auto-close
        fi
        ;;

      "Convertir un video local a audio")
        FILE=$(zenity --file-selection --title="Selecciona un video local")
        ffmpeg -i "$FILE" -q:a 0 -map a "$DEST/$(basename "${FILE%.*}.mp3")" | zenity --progress --pulsate --auto-close
        ;;

      "Instalar reproductores multimedia")
        REPROS=$(zenity --list --checklist --title="Instalar reproductores" --column="Seleccionado" --column="Reproductor" TRUE "vlc" FALSE "audacity" FALSE "celluloid" FALSE "qmmp" FALSE "lollypop" --separator=" ")
        sudo apt install -y $REPROS
        ;;

      "Desinstalar reproductores multimedia")
        REPROS=$(zenity --list --checklist --title="Desinstalar reproductores" --column="Seleccionado" --column="Reproductor" FALSE "vlc" FALSE "audacity" FALSE "celluloid" FALSE "qmmp" FALSE "lollypop" --separator=" ")
        sudo apt remove -y $REPROS
        ;;

      "Cambiar carpeta de descarga")
        select_folder
        ;;

      "Salir") break ;;
    esac
  done
}

check_and_install
main_menu
