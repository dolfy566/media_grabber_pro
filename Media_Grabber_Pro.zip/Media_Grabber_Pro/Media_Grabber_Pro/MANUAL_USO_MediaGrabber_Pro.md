# 📱 MANUAL DE USO - MediaGrabber Pro

## 🎯 REQUISITO FUNDAMENTAL
**Debes estar LOGUEADO en el sitio web** para poder descargar videos protegidos.

## 🔐 PROCESO DE AUTENTICACIÓN

### Paso 1: Iniciar Sesión
1. **Abrir** el sitio web en tu navegador
2. **Iniciar sesión** con tu cuenta de usuario
3. **Verificar** que puedes ver el video normalmente

### Paso 2: Obtener Cookie de Sesión
1. **Instalar extensión**: Get cookies.txt LOCALLY (Firefox/Chrome)
2. **Click en la extensión** → Export cookies.txt
3. **Guardar** el archivo en la misma carpeta que el programa

## 📋 USO DEL PROGRAMA

### Archivos Necesarios
- `MediaGrabber_Pro.exe` (programa)
- `cookies.txt` (archivo de autenticación)

### Proceso Simple
1. **Abrir** el programa
2. **Pegar** URL del video
3. **Click en DESCARGAR**

## ⚠️ IMPORTANTE
- **Sin login**: Solo funcionará para videos públicos
- **con login**: Funciona para videos que requieren autenticación
- **cookies.txt** debe contener tu sesión activa
